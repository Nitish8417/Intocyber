<section>
    <div class="container">
        <div class="main-accord-block">
            <div class="left-img-accord">
                <img src="http://localhost/IntoCyber/wp-content/uploads/2024/05/Rectangle2055.png" alt="img">
            </div>
            <div class="right-accord-block">
                <h2>Global Expansion Solutions</h2>
                <p class="p16">Speed to Market is crucial to launch and expand you business. By having a local office your proximity to the customer is established immediately.
                    We bring this to you immediately without any cost upfront.
                </p>
                <p class="p24">The Strategic Importance of Local Sales Offices for Cybersecurity Companies
                </p>
                <div class="accordion-block">
                    <div class="accordion-block-item">
                        <div class="accordion-text-item-list">
                            <div class="accordion-title">
                                <h5>Complex and Evolving Product Offerings</h5>
                            </div>
                            <div class="accordion-decp">
                                <p>We bring the route to quality end customer and channel management to stay ahead of the curve against our competition.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-block-item">

                        <div class="accordion-text-item-list">
                            <div class="accordion-title">
                                <h5>Complex and Evolving Product Offerings</h5>
                            </div>
                            <div class="accordion-decp">
                                <p>We bring the route to quality end customer and channel management to stay ahead of the curve against our competition.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-block-item">
                        <div class="accordion-text-item-list">
                            <div class="accordion-title">
                                <h5>Complex and Evolving Product Offerings</h5>
                            </div>
                            <div class="accordion-decp">
                                <p>We bring the route to quality end customer and channel management to stay ahead of the curve against our competition.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-block-item">

                        <div class="accordion-text-item-list">
                            <div class="accordion-title">
                                <h5>Complex and Evolving Product Offerings</h5>
                            </div>
                            <div class="accordion-decp">
                                <p>We bring the route to quality end customer and channel management to stay ahead of the curve against our competition.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-block-item">
                        <div class="accordion-text-item-list">
                            <div class="accordion-title">
                                <h5>Complex and Evolving Product Offerings</h5>
                            </div>
                            <div class="accordion-decp">
                                <p>We bring the route to quality end customer and channel management to stay ahead of the curve against our competition.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-block-item">
                        <div class="accordion-text-item-list">
                            <div class="accordion-title">
                                <h5>Complex and Evolving Product Offerings</h5>
                            </div>
                            <div class="accordion-decp">
                                <p>We bring the route to quality end customer and channel management to stay ahead of the curve against our competition.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-block-item">
                        <div class="accordion-text-item-list">
                            <div class="accordion-title">
                                <h5>Complex and Evolving Product Offerings</h5>
                            </div>
                            <div class="accordion-decp">
                                <p>We bring the route to quality end customer and channel management to stay ahead of the curve against our competition.</p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
