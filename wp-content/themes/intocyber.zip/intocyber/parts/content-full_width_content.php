<?php if(!empty($section_block)): 
	$full_width_content_text = $section_block['full_width_content_text'];	
?>
<section id="full-text-info">
    <div class="sub-full-text-info">
        <div class="container">
            <div class="full-text-block">
                <p class="p31"><?php echo $full_width_content_text; ?></p>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>